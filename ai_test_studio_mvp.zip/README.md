# AI Test Studio (MVP)

A local-first automated website testing dashboard for developers and QA teams.

## What it does
- Accepts a website URL and runs browser-based smoke checks with Playwright.
- Checks page load, page title, broken images, links, buttons, and browser console errors.
- Saves a screenshot and returns a readable pass/fail report.
- Shows a **Workday Impact Brief**: severity, likely user impact, and the next action to take.
- Exports results as JSON for tickets, reports, or CI workflows.

## Stack
- Python 3.11+
- FastAPI + Uvicorn
- Playwright (Chromium)
- HTML/CSS/JavaScript dashboard (no frontend build step)

## Run locally
```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
playwright install chromium
uvicorn app.main:app --reload
```
Open http://127.0.0.1:8000

## Safety notes
- This MVP is intended for local development and testing websites you own or are authorized to test.
- Keep the server bound to 127.0.0.1. Do not expose it publicly without authentication, authorization, rate limits, and network/SSRF protections.
- Do not enter production credentials or sensitive customer data.
- Browser checks are heuristics, not proof that an application is defect-free.
- AI-based test generation and self-healing are planned extensions, not claimed as implemented in this MVP.

## Suggested next milestones
1. Add saved projects and test history using SQLite/PostgreSQL.
2. Add authentication, teams, role-based access and audit logs.
3. Add GitHub Actions integration and scheduled runs.
4. Add AI-generated test cases from requirements, with human review before execution.
5. Add change-aware test selection and flaky-test detection.
6. Add cross-browser runs (Firefox/WebKit) and optional device cloud integration.
