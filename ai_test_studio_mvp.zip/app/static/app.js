const form = document.getElementById("test-form");
const runButton = document.getElementById("run-button");
const errorBox = document.getElementById("error-box");
const results = document.getElementById("results");
let latestResult = null;

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  errorBox.classList.add("hidden");
  results.classList.add("hidden");
  runButton.disabled = true;
  runButton.textContent = "Running checks…";
  try {
    const response = await fetch("/api/run", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({
        url: document.getElementById("url").value.trim(),
        timeout_seconds: Number(document.getElementById("timeout").value)
      })
    });
    const payload = await response.json();
    if (!response.ok) throw new Error(payload.detail || "The test run failed.");
    latestResult = payload;
    renderResult(payload);
  } catch (error) {
    errorBox.textContent = error.message || "Unable to run tests. Check that the API and Playwright browser are installed.";
    errorBox.classList.remove("hidden");
  } finally {
    runButton.disabled = false;
    runButton.innerHTML = "<span>▶</span> Run tests";
  }
});

function renderResult(data) {
  results.classList.remove("hidden");
  document.getElementById("result-title").textContent = data.title || new URL(data.url).hostname;
  document.getElementById("result-meta").textContent = `${data.final_url} · ${new Date(data.created_at).toLocaleString()}`;
  document.getElementById("score").textContent = data.score;
  document.getElementById("passed").textContent = `${data.summary.passed}/${data.summary.checks}`;
  document.getElementById("checks-label").textContent = `${data.summary.failed} failed check(s)`;
  document.getElementById("issue-count").textContent = data.issues.length;
  document.getElementById("duration").textContent = `${data.duration_seconds}s`;
  document.getElementById("impact-headline").textContent = data.workday_impact_brief.headline;
  document.getElementById("first-action").textContent = data.workday_impact_brief.recommended_first_action;

  const checks = document.getElementById("checks-list");
  checks.replaceChildren();
  data.checks.forEach(check => {
    const row = document.createElement("div");
    row.className = "check-row";
    const state = check.status;
    const icon = state === "pass" ? "✓" : state === "fail" ? "!" : "i";
    row.innerHTML = `<span class="check-icon ${state}">${icon}</span><div><div class="check-name"></div><div class="check-message"></div></div><span class="check-status ${state}">${state}</span>`;
    row.querySelector(".check-name").textContent = check.name;
    row.querySelector(".check-message").textContent = check.message;
    checks.appendChild(row);
  });

  const issues = document.getElementById("issues-list");
  issues.replaceChildren();
  if (!data.issues.length) {
    const message = document.createElement("p");
    message.textContent = "No issue signals were detected in this run. Keep the report as a baseline and run again after changes.";
    message.className = "subtitle";
    issues.appendChild(message);
  }
  data.issues.forEach(issue => {
    const card = document.createElement("div");
    card.className = "issue";
    card.innerHTML = `<div class="issue-top"><strong class="severity"></strong></div><div class="issue-detail"></div><div class="issue-action"></div>`;
    const severity = card.querySelector(".severity");
    severity.textContent = issue.severity;
    severity.classList.add(issue.severity.toLowerCase());
    card.querySelector(".issue-detail").textContent = issue.detail;
    card.querySelector(".issue-action").textContent = issue.recommended_action;
    issues.appendChild(card);
  });

  const shot = document.getElementById("screenshot");
  const shotLink = document.getElementById("screenshot-link");
  if (data.screenshot_available) {
    const src = `/api/results/${data.id}/screenshot`;
    shot.src = src;
    shot.classList.remove("hidden");
    shotLink.href = src;
    shotLink.classList.remove("hidden");
  } else {
    shot.classList.add("hidden");
    shotLink.classList.add("hidden");
  }
  results.scrollIntoView({behavior: "smooth", block: "start"});
}

document.getElementById("download-json").addEventListener("click", () => {
  if (!latestResult) return;
  const blob = new Blob([JSON.stringify(latestResult, null, 2)], {type: "application/json"});
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = `ai-test-studio-${latestResult.id}.json`;
  anchor.click();
  URL.revokeObjectURL(url);
});
