from __future__ import annotations

import asyncio
import json
import re
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlparse

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, HttpUrl
from playwright.async_api import async_playwright, TimeoutError as PlaywrightTimeoutError

BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR / "static"
RESULTS_DIR = BASE_DIR.parent / "test-results"
RESULTS_DIR.mkdir(exist_ok=True)

app = FastAPI(
    title="AI Test Studio",
    description="Local-first automated website smoke testing with a workday impact brief.",
    version="0.1.0",
)
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


class RunRequest(BaseModel):
    url: HttpUrl
    timeout_seconds: int = Field(default=20, ge=5, le=60)


def safe_url(value: str) -> str:
    parsed = urlparse(value)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        raise HTTPException(status_code=400, detail="Only valid http:// or https:// URLs are supported.")
    # This app is designed to run locally against public sites or explicitly authorized test targets.
    # Do not deploy publicly without a strict outbound network allowlist and SSRF protections.
    return value


def classify_issue(kind: str, detail: str) -> dict:
    low = detail.lower()
    if kind == "navigation":
        severity, impact, action = "Critical", "The page could not be opened, so users may be blocked from the workflow.", "Check the URL, server availability, redirects, and TLS/network errors."
    elif kind == "console":
        severity, impact, action = "High", "A browser-side error may break an interactive feature.", "Open the browser trace and fix the first application error; rerun the test."
    elif kind == "broken_image":
        severity, impact, action = "Low", "A visual asset may be missing or incorrectly served.", "Verify the image path and static-file deployment."
    elif kind == "empty_title":
        severity, impact, action = "Medium", "The page has no useful document title for users or browser tabs.", "Add a descriptive, unique HTML title."
    elif kind == "no_buttons":
        severity, impact, action = "Info", "No buttons were detected; this may be expected for a content-only page.", "Confirm whether the page should contain interactive controls."
    elif kind == "link":
        severity, impact, action = "Medium", "A link may lead to a missing page or server error.", "Verify the destination and expected status; some external sites block automated checks."
    else:
        severity, impact, action = "Medium", "This check needs human review.", "Inspect the page and rerun after changes."
    return {"type": kind, "severity": severity, "detail": detail, "user_impact": impact, "recommended_action": action}


@app.get("/", response_class=HTMLResponse)
async def dashboard():
    return FileResponse(STATIC_DIR / "index.html")


@app.get("/api/health")
async def health():
    return {"status": "ok", "service": "AI Test Studio", "version": "0.1.0"}


@app.get("/api/results/{result_id}")
async def get_result(result_id: str):
    if not re.fullmatch(r"[a-f0-9-]{36}", result_id):
        raise HTTPException(status_code=400, detail="Invalid result ID.")
    path = RESULTS_DIR / f"{result_id}.json"
    if not path.exists():
        raise HTTPException(status_code=404, detail="Result not found.")
    return json.loads(path.read_text(encoding="utf-8"))


@app.get("/api/results/{result_id}/screenshot")
async def get_screenshot(result_id: str):
    if not re.fullmatch(r"[a-f0-9-]{36}", result_id):
        raise HTTPException(status_code=400, detail="Invalid result ID.")
    path = RESULTS_DIR / f"{result_id}.png"
    if not path.exists():
        raise HTTPException(status_code=404, detail="Screenshot not found.")
    return FileResponse(path, media_type="image/png")


@app.post("/api/run")
async def run_test(request: RunRequest):
    url = safe_url(str(request.url))
    run_id = str(uuid.uuid4())
    started = time.perf_counter()
    console_errors: list[str] = []
    issues: list[dict] = []
    checks: list[dict] = []
    screenshot_path = RESULTS_DIR / f"{run_id}.png"
    title = ""
    final_url = url
    page_status = None

    def add_check(name: str, status: str, message: str):
        checks.append({"name": name, "status": status, "message": message})

    try:
        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=True)
            page = await browser.new_page(viewport={"width": 1440, "height": 900})
            page.on("console", lambda msg: console_errors.append(msg.text) if msg.type == "error" else None)
            page.on("pageerror", lambda error: console_errors.append(str(error)))
            try:
                response = await page.goto(url, wait_until="domcontentloaded", timeout=request.timeout_seconds * 1000)
                final_url = page.url
                page_status = response.status if response else None
                title = (await page.title()).strip()

                if response and response.status >= 400:
                    issues.append(classify_issue("navigation", f"Initial document returned HTTP {response.status}."))
                    add_check("HTTP response", "fail", f"HTTP {response.status}")
                else:
                    add_check("HTTP response", "pass", f"Document loaded{f' (HTTP {page_status})' if page_status else ''}")

                add_check("Page load", "pass", f"DOM loaded at {final_url}")
                if title:
                    add_check("Document title", "pass", title)
                else:
                    issues.append(classify_issue("empty_title", "Document title is empty."))
                    add_check("Document title", "fail", "No page title found.")

                # Lightweight usability checks; findings are intentionally framed as signals, not guarantees.
                image_info = await page.locator("img").evaluate_all(
                    """imgs => imgs.map(i => ({src: i.currentSrc || i.src, alt: i.getAttribute('alt'), complete: i.complete, width: i.naturalWidth}))"""
                )
                broken_images = [i for i in image_info if i.get("src") and (not i.get("complete") or i.get("width", 0) == 0)]
                if broken_images:
                    for img in broken_images[:10]:
                        issues.append(classify_issue("broken_image", f"Image did not load: {img.get('src', '')[:220]}"))
                    add_check("Images", "fail", f"{len(broken_images)} of {len(image_info)} image(s) may be broken.")
                else:
                    add_check("Images", "pass", f"{len(image_info)} image(s) inspected; no broken images detected.")

                links = await page.locator("a[href]").evaluate_all(
                    """els => els.slice(0, 40).map(a => ({href: a.href, text: (a.innerText || a.getAttribute('aria-label') || '').trim()}))"""
                )
                checked_links = 0
                bad_links = []
                for link in links:
                    target = link.get("href", "")
                    parsed = urlparse(target)
                    if parsed.scheme not in {"http", "https"}:
                        continue
                    # Only check same-origin links to avoid noisy third-party failures.
                    if urlparse(final_url).netloc != parsed.netloc:
                        continue
                    checked_links += 1
                    try:
                        result = await page.request.get(target, timeout=min(request.timeout_seconds * 1000, 8000))
                        if result.status >= 400:
                            bad_links.append((target, result.status))
                    except Exception:
                        bad_links.append((target, "request failed"))
                if bad_links:
                    for target, status in bad_links[:10]:
                        issues.append(classify_issue("link", f"{target} returned {status}."))
                    add_check("Internal links", "fail", f"{len(bad_links)} failing link(s) among {checked_links} checked.")
                else:
                    add_check("Internal links", "pass", f"{checked_links} same-origin link(s) checked; none failed.")

                button_count = await page.locator("button, input[type=button], input[type=submit], [role=button]").count()
                if button_count:
                    add_check("Interactive controls", "pass", f"Detected {button_count} button-like control(s).")
                else:
                    issues.append(classify_issue("no_buttons", "No button-like controls detected."))
                    add_check("Interactive controls", "info", "No button-like controls detected; may be expected.")

                if console_errors:
                    unique_errors = list(dict.fromkeys(console_errors))[:10]
                    for error in unique_errors:
                        issues.append(classify_issue("console", error[:500]))
                    add_check("Browser console", "fail", f"{len(console_errors)} console/page error(s) detected.")
                else:
                    add_check("Browser console", "pass", "No browser console or uncaught page errors detected.")

                await page.screenshot(path=str(screenshot_path), full_page=True)
            except PlaywrightTimeoutError:
                issues.append(classify_issue("navigation", f"Navigation timed out after {request.timeout_seconds} seconds."))
                add_check("Page load", "fail", f"Timed out after {request.timeout_seconds} seconds.")
            except Exception as exc:
                issues.append(classify_issue("navigation", f"Browser check failed: {str(exc)[:400]}"))
                add_check("Page load", "fail", str(exc)[:400])
            finally:
                await browser.close()
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Could not launch browser. Run `playwright install chromium`. Details: {str(exc)[:250]}")

    elapsed = round(time.perf_counter() - started, 2)
    critical = sum(1 for i in issues if i["severity"] == "Critical")
    high = sum(1 for i in issues if i["severity"] == "High")
    medium = sum(1 for i in issues if i["severity"] == "Medium")
    failed_checks = sum(1 for c in checks if c["status"] == "fail")
    score = max(0, round(100 - critical * 35 - high * 20 - medium * 10 - sum(1 for i in issues if i["severity"] == "Low") * 3))
    result = {
        "id": run_id,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "url": url,
        "final_url": final_url,
        "title": title,
        "http_status": page_status,
        "duration_seconds": elapsed,
        "score": score,
        "status": "passed" if failed_checks == 0 else "needs_attention",
        "summary": {"checks": len(checks), "passed": sum(1 for c in checks if c["status"] == "pass"), "failed": failed_checks, "issues": len(issues)},
        "checks": checks,
        "issues": issues,
        "workday_impact_brief": {
            "headline": "Ready for review" if not issues else f"{len(issues)} issue signal(s) to review",
            "priority_order": ["Critical", "High", "Medium", "Low", "Info"],
            "recommended_first_action": issues[0]["recommended_action"] if issues else "Save this baseline and run the same checks after the next change.",
            "note": "This is a heuristic smoke-test report, not a guarantee of complete application quality."
        },
        "screenshot_available": screenshot_path.exists(),
    }
    (RESULTS_DIR / f"{run_id}.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    return result
